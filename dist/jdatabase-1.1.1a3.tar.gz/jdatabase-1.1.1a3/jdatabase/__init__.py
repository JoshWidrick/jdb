from jdatabase import jdatabase
from jdatabase.jdatabase import Jdatabase